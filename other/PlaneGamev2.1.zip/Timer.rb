class Timer

	def initialize(window, bullets) 
		@bullets = bullets
		@window = window
		@start_time = Time.now
		@every_n_seconds = 5
		@last_recorded_seconds = 0

	end
	def add_bullets?
		if seconds !=
	end
end